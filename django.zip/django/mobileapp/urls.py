from django.contrib import admin
from django.urls import path
from.import views

urlpatterns = [
    
    path('',views.home,name='home'), 
    path('login',views.login_page,name='login'),
    path('logout',views.logout_page,name='logout'),
    path('cartpage',views.cart_page,name='cartpage'),
    path('remove_cart/<str:cid>',views.remove_cart,name='remove_cart'),
    # path('collection',views.collection,name='collection'), 
    path('about',views.about,name='about'),
    path('contact',views.contact,name='contact'), 
    path('register',views.register,name='register'),
    path('collection',views.collection,name='collection'),
    path('collection/<str:name>',views.collectionview,name='collection'),
    path('collection/<str:cname>/<str:pname>',views.productdetails,name='productdetails'),
    path('addtocart',views.add_to_cart,name='addtocart'),
]
